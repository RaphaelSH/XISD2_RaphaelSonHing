﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace POE
{
    public partial class DeleteVehicle : Form
    {
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataReader datareader;
        Connection connect = new Connection();
        public DeleteVehicle()
        {
            InitializeComponent();
            connectionDB();
            Prep();
        }

        public void Prep()
        {
            conn.Open();
            string sql = "select * from [dbo].[Employee]";
            cmd = new SqlCommand(sql, conn);
            using (datareader = cmd.ExecuteReader())
            {
                while (datareader.Read())
                {
                    cbVehicleid.Items.Add(datareader["EmployeeID"]);

                }
            }
            conn.Close();
        }

        public void connectionDB()
        {
            string strConn = connect.getConnecection();
            // create a new database connection:
            conn = new SqlConnection(strConn);
        }


        private void btnDelete_Click(object sender, EventArgs e)
        {
            Delete();
        }
        public void Delete()
        {

            Vehicle vehicle = new Vehicle();
            int intVehicleID = Convert.ToInt32(cbVehicleid.Text);
            conn.Open();

            try
            {
                string sql = "Delete from [dbo].[Vehicle] where VehicleNumberID = @id";
                vehicle.VehicleID = intVehicleID;

                cmd = new SqlCommand(sql, conn);
                // Lets insert something into our new table:
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@id", Convert.ToInt32(vehicle.VehicleID));
                cmd.ExecuteNonQuery();
                MessageBox.Show("Vehicle ID" + vehicle.VehicleID);
            }
            catch (SqlException ex)
            {
                Exception error = new Exception("Sorry! Unable to delete",
                ex);
                throw error;
            }
            cmd.Parameters.Clear();
            conn.Close();
        }

        private void addEmployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddEmployee employee = new AddEmployee();
            employee.ShowDialog();
        }

        private void addVehicleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddVehicle vehicle = new AddVehicle();
            vehicle.ShowDialog();
        }

        private void addTripToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddTrip trip = new AddTrip();
            trip.ShowDialog();
        }

        private void viewReportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            a report = new a();
            report.ShowDialog();
        }

        private void makeAppointmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            MakeAppointment appoint = new MakeAppointment();
            appoint.ShowDialog();
        }

        private void deleteEmployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Delete deleteEmp = new Delete();
            deleteEmp.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.ShowDialog();
        }
    }
}
