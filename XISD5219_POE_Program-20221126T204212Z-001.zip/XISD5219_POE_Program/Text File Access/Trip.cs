﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE
{
    class Trip
    {
        public int TripID { get; set; }
        public string TripDate { get; set; }
        public int KMtoTravel { get; set; }
        public int KMTravelled { get; set; }
        public string Destination { get; set; }
    }
}
