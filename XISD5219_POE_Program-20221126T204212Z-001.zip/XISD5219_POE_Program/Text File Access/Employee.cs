﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public String Name { get; set; }
        public String Surname { get; set; }
        public String Postion { get; set; }
       
    }
}
