﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace POE
{
    public partial class AddVehicle : Form
    {
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataReader datareader;
        Vehicle vehicle = new Vehicle();
        Random num = new Random();
        Connection connect = new Connection();
        public AddVehicle()
        {
            InitializeComponent();
            connectionDB();
            
        }

        //create database
        public void connectionDB()
        {
            string strConn = connect.getConnecection();
            // create a new database connection:
            conn = new SqlConnection (strConn);
         
           
        }

        public void WriteToDatabase()
        {
            int count = 0;
            

            try
            {
                conn.Open();


                vehicle.VehicleType = txtVehicleType.Text;
                vehicle.Manufacturer = txtManufacturer.Text;
                vehicle.EngineSize = txtEngineSize.Text;
                vehicle.CurrOdometer = Convert.ToInt32(nudCurrOdo.Value);
                vehicle.NextOdometer = Convert.ToInt32(nudOdoNext.Value);
                vehicle.VehicleID= num.Next(1000, 9999);
                int ran = num.Next(1000, 9999);
                vehicle.RegistrationNumber = "H"+Convert.ToString(ran);
                string sql = "select * from [dbo].[Vehicle] where VehicleNumberID = @vehicleid";
                cmd = new SqlCommand(sql, conn);
                //Checks for identical ApppointmentID entries then re-randomizes AppointmentID
                cmd.CommandText = sql; 
                cmd.Parameters.AddWithValue("@vehicleid", vehicle.VehicleID);
                count = Convert.ToInt32(cmd.ExecuteScalar());
                if (count == 1)
                {
                    vehicle.VehicleID = num.Next(1000, 9999);
                }




                sql = "INSERT INTO [dbo].[Vehicle] (VehicleNumberID,RegistrationNumber,VehicleType,Manufacturer,EngineSize,CurrOdometerReading,NextOdometerReading) VALUES (@id,@register,@vehicletype,@manufac,@engine,@currodo,@nextodo)";
                cmd = new SqlCommand(sql, conn);  
                // Lets insert something into our new table:
                cmd.CommandText = sql; 
                cmd.Parameters.AddWithValue("@id", Convert.ToInt32(vehicle.VehicleID));
                cmd.Parameters.AddWithValue("@register", vehicle.RegistrationNumber);
                cmd.Parameters.AddWithValue("@vehicletype",vehicle.VehicleType);
                cmd.Parameters.AddWithValue("@manufac", vehicle.Manufacturer);
                cmd.Parameters.AddWithValue("@engine", vehicle.EngineSize);
                cmd.Parameters.AddWithValue("@currodo",Convert.ToInt32( vehicle.CurrOdometer));
                cmd.Parameters.AddWithValue("@nextodo",Convert.ToInt32( vehicle.NextOdometer));
                //Execute query to insert data into database
                cmd.ExecuteNonQuery();
                cmd.Parameters.Clear();
                MessageBox.Show("Vehicle successfully made");
                Clear();
            }
            catch (Exception e)
            {
                MessageBox.Show("Error add Vehicle\n" + e);
                Clear();
            }
            finally {
                conn.Close();
            }
           
        }

        public void Clear()
        {
            txtManufacturer.Text = "";
            txtVehicleType.Text = "";
            txtEngineSize.Text = "";
            nudCurrOdo.Value = 0;
            nudOdoNext.Value = 0;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            WriteToDatabase();
        }

        
        private void btnView_Click(object sender, EventArgs e)
        {

        }

        private void addEmployeeToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AddEmployee employee = new AddEmployee();
            employee.ShowDialog();
        }

        private void scheduleTripToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddTrip trip = new AddTrip();
            trip.ShowDialog();
        }

        private void viewReportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            a report = new a();
            report.ShowDialog();
        }

        private void makToolStripMenuItem_Click(object sender, EventArgs e)
        {

            this.Hide();
            MakeAppointment make = new MakeAppointment();
            make.ShowDialog();
        }

        private void deleteEmploeeRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Delete deleteEmp = new Delete();
            deleteEmp.ShowDialog();
        }

        private void deleteAppointmentRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            DeleteAppointment deleteAppoint = new DeleteAppointment();
            deleteAppoint.ShowDialog();
        }

        private void deleteVehicleRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            DeleteVehicle deleteVehicle = new DeleteVehicle();
            deleteVehicle.ShowDialog();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.ShowDialog();
        }

        private void eixtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }
    }
}
