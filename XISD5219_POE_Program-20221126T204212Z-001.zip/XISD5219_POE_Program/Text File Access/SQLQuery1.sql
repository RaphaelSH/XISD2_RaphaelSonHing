﻿sp_configure 'contained database authentication', 1;  
GO  
RECONFIGURE;  
GO  