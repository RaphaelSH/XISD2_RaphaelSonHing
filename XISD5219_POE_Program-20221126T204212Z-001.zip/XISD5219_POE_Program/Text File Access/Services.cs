﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE
{
    class Services
    {
        public string ProcedureCode { get; set; }
        public string ServiceType { get; set; }
        public string Description { get; set; }
    }
}
