﻿namespace POE
{
    partial class a
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(a));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.cbVehicleNo = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.rtbDisplay = new System.Windows.Forms.RichTextBox();
            this.btnReport5 = new System.Windows.Forms.Button();
            this.btnReport4 = new System.Windows.Forms.Button();
            this.btnReport3 = new System.Windows.Forms.Button();
            this.btnReport2 = new System.Windows.Forms.Button();
            this.btnReport1 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addEmployeeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addVehicleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.scheduleTripToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteEmploeeRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteVehicleRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteAppointmentRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.appointmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.makeAppointmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Teal;
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.cbVehicleNo);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.rtbDisplay);
            this.groupBox1.Controls.Add(this.btnReport5);
            this.groupBox1.Controls.Add(this.btnReport4);
            this.groupBox1.Controls.Add(this.btnReport3);
            this.groupBox1.Controls.Add(this.btnReport2);
            this.groupBox1.Controls.Add(this.btnReport1);
            this.groupBox1.Location = new System.Drawing.Point(67, 39);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(568, 534);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(24, 29);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(512, 86);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // cbVehicleNo
            // 
            this.cbVehicleNo.FormattingEnabled = true;
            this.cbVehicleNo.Location = new System.Drawing.Point(5, 290);
            this.cbVehicleNo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbVehicleNo.Name = "cbVehicleNo";
            this.cbVehicleNo.Size = new System.Drawing.Size(147, 24);
            this.cbVehicleNo.TabIndex = 22;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(15, 265);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(125, 25);
            this.label5.TabIndex = 21;
            this.label5.Text = "Vehicle No.";
            // 
            // rtbDisplay
            // 
            this.rtbDisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rtbDisplay.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbDisplay.Location = new System.Drawing.Point(193, 130);
            this.rtbDisplay.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rtbDisplay.Name = "rtbDisplay";
            this.rtbDisplay.Size = new System.Drawing.Size(343, 362);
            this.rtbDisplay.TabIndex = 18;
            this.rtbDisplay.Text = "";
            // 
            // btnReport5
            // 
            this.btnReport5.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnReport5.FlatAppearance.BorderSize = 0;
            this.btnReport5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Khaki;
            this.btnReport5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReport5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReport5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnReport5.Location = new System.Drawing.Point(5, 398);
            this.btnReport5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnReport5.Name = "btnReport5";
            this.btnReport5.Size = new System.Drawing.Size(147, 39);
            this.btnReport5.TabIndex = 14;
            this.btnReport5.Text = "Report 5";
            this.btnReport5.UseVisualStyleBackColor = false;
            // 
            // btnReport4
            // 
            this.btnReport4.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnReport4.FlatAppearance.BorderSize = 0;
            this.btnReport4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Khaki;
            this.btnReport4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReport4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReport4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnReport4.Location = new System.Drawing.Point(5, 352);
            this.btnReport4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnReport4.Name = "btnReport4";
            this.btnReport4.Size = new System.Drawing.Size(147, 39);
            this.btnReport4.TabIndex = 13;
            this.btnReport4.Text = "Report 4";
            this.btnReport4.UseVisualStyleBackColor = false;
            // 
            // btnReport3
            // 
            this.btnReport3.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnReport3.FlatAppearance.BorderSize = 0;
            this.btnReport3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Khaki;
            this.btnReport3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReport3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReport3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnReport3.Location = new System.Drawing.Point(5, 222);
            this.btnReport3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnReport3.Name = "btnReport3";
            this.btnReport3.Size = new System.Drawing.Size(147, 39);
            this.btnReport3.TabIndex = 12;
            this.btnReport3.Text = "Report 3";
            this.btnReport3.UseVisualStyleBackColor = false;
            this.btnReport3.Click += new System.EventHandler(this.btnReport3_Click);
            // 
            // btnReport2
            // 
            this.btnReport2.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnReport2.FlatAppearance.BorderSize = 0;
            this.btnReport2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Khaki;
            this.btnReport2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReport2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReport2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnReport2.Location = new System.Drawing.Point(5, 176);
            this.btnReport2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnReport2.Name = "btnReport2";
            this.btnReport2.Size = new System.Drawing.Size(147, 39);
            this.btnReport2.TabIndex = 11;
            this.btnReport2.Text = "Report 2";
            this.btnReport2.UseVisualStyleBackColor = false;
            this.btnReport2.Click += new System.EventHandler(this.btnReport2_Click);
            // 
            // btnReport1
            // 
            this.btnReport1.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnReport1.FlatAppearance.BorderSize = 0;
            this.btnReport1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Khaki;
            this.btnReport1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReport1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReport1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnReport1.Location = new System.Drawing.Point(5, 130);
            this.btnReport1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnReport1.Name = "btnReport1";
            this.btnReport1.Size = new System.Drawing.Size(147, 39);
            this.btnReport1.TabIndex = 0;
            this.btnReport1.Text = "Report 1";
            this.btnReport1.UseVisualStyleBackColor = false;
            this.btnReport1.Click += new System.EventHandler(this.btnReport1_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.White;
            this.menuStrip1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addToolStripMenuItem,
            this.deleteToolStripMenuItem,
            this.appointmentToolStripMenuItem,
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(683, 26);
            this.menuStrip1.TabIndex = 20;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addEmployeeToolStripMenuItem,
            this.addVehicleToolStripMenuItem,
            this.scheduleTripToolStripMenuItem});
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new System.Drawing.Size(50, 22);
            this.addToolStripMenuItem.Text = "Add";
            // 
            // addEmployeeToolStripMenuItem
            // 
            this.addEmployeeToolStripMenuItem.Name = "addEmployeeToolStripMenuItem";
            this.addEmployeeToolStripMenuItem.Size = new System.Drawing.Size(196, 26);
            this.addEmployeeToolStripMenuItem.Text = "Add Employee";
            this.addEmployeeToolStripMenuItem.Click += new System.EventHandler(this.addEmployeeToolStripMenuItem_Click_1);
            // 
            // addVehicleToolStripMenuItem
            // 
            this.addVehicleToolStripMenuItem.Name = "addVehicleToolStripMenuItem";
            this.addVehicleToolStripMenuItem.Size = new System.Drawing.Size(196, 26);
            this.addVehicleToolStripMenuItem.Text = "Add Vehicle";
            this.addVehicleToolStripMenuItem.Click += new System.EventHandler(this.addVehicleToolStripMenuItem_Click_1);
            // 
            // scheduleTripToolStripMenuItem
            // 
            this.scheduleTripToolStripMenuItem.Name = "scheduleTripToolStripMenuItem";
            this.scheduleTripToolStripMenuItem.Size = new System.Drawing.Size(196, 26);
            this.scheduleTripToolStripMenuItem.Text = "Schedule Trip";
            this.scheduleTripToolStripMenuItem.Click += new System.EventHandler(this.scheduleTripToolStripMenuItem_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteEmploeeRecordToolStripMenuItem,
            this.deleteVehicleRecordToolStripMenuItem,
            this.deleteAppointmentRecordToolStripMenuItem});
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(69, 22);
            this.deleteToolStripMenuItem.Text = "Delete";
            // 
            // deleteEmploeeRecordToolStripMenuItem
            // 
            this.deleteEmploeeRecordToolStripMenuItem.Name = "deleteEmploeeRecordToolStripMenuItem";
            this.deleteEmploeeRecordToolStripMenuItem.Size = new System.Drawing.Size(294, 26);
            this.deleteEmploeeRecordToolStripMenuItem.Text = "Delete Employee Record";
            this.deleteEmploeeRecordToolStripMenuItem.Click += new System.EventHandler(this.deleteEmploeeRecordToolStripMenuItem_Click);
            // 
            // deleteVehicleRecordToolStripMenuItem
            // 
            this.deleteVehicleRecordToolStripMenuItem.Name = "deleteVehicleRecordToolStripMenuItem";
            this.deleteVehicleRecordToolStripMenuItem.Size = new System.Drawing.Size(294, 26);
            this.deleteVehicleRecordToolStripMenuItem.Text = "Delete Vehicle Record";
            this.deleteVehicleRecordToolStripMenuItem.Click += new System.EventHandler(this.deleteVehicleRecordToolStripMenuItem_Click);
            // 
            // deleteAppointmentRecordToolStripMenuItem
            // 
            this.deleteAppointmentRecordToolStripMenuItem.Name = "deleteAppointmentRecordToolStripMenuItem";
            this.deleteAppointmentRecordToolStripMenuItem.Size = new System.Drawing.Size(294, 26);
            this.deleteAppointmentRecordToolStripMenuItem.Text = "Delete Appointment Record";
            this.deleteAppointmentRecordToolStripMenuItem.Click += new System.EventHandler(this.deleteAppointmentRecordToolStripMenuItem_Click);
            // 
            // appointmentToolStripMenuItem
            // 
            this.appointmentToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.makeAppointmentToolStripMenuItem});
            this.appointmentToolStripMenuItem.Name = "appointmentToolStripMenuItem";
            this.appointmentToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.appointmentToolStripMenuItem.Text = "Appointment";
            // 
            // makeAppointmentToolStripMenuItem
            // 
            this.makeAppointmentToolStripMenuItem.Name = "makeAppointmentToolStripMenuItem";
            this.makeAppointmentToolStripMenuItem.Size = new System.Drawing.Size(230, 26);
            this.makeAppointmentToolStripMenuItem.Text = "Make Appointment";
            this.makeAppointmentToolStripMenuItem.Click += new System.EventHandler(this.makeAppointmentToolStripMenuItem_Click);
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logoutToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(46, 22);
            this.fileToolStripMenuItem.Text = "File";
            this.fileToolStripMenuItem.Click += new System.EventHandler(this.fileToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(142, 26);
            this.logoutToolStripMenuItem.Text = "Logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(142, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // a
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.ClientSize = new System.Drawing.Size(683, 614);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "a";
            this.Text = "Report";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnReport1;
        private System.Windows.Forms.Button btnReport5;
        private System.Windows.Forms.Button btnReport4;
        private System.Windows.Forms.Button btnReport3;
        private System.Windows.Forms.Button btnReport2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addEmployeeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addVehicleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scheduleTripToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteEmploeeRecordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem appointmentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem makeAppointmentToolStripMenuItem;
        private System.Windows.Forms.RichTextBox rtbDisplay;
        private System.Windows.Forms.ComboBox cbVehicleNo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ToolStripMenuItem deleteVehicleRecordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteAppointmentRecordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}