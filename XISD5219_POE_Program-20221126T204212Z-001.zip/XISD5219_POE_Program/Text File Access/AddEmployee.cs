﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace POE
{
    public partial class AddEmployee : Form
    {
        SqlConnection conn;
        SqlCommand cmd;
       // SqlDataReader datareader;
        Employee employee = new Employee();
        Random num = new Random();
        Connection connect = new Connection();
        public AddEmployee()
        {
            InitializeComponent();
            connectionDB();
            
        }

        //create database
        public void connectionDB()
        {
            string strConn = connect.getConnecection();
            // create a new database connection:
            conn = new SqlConnection (strConn);
         
           
        }

        public void WriteToDatabase()
        {
            int count = 0;
            

            try
            {
                conn.Open();


                employee.Name = txtName.Text;
                employee.Surname = txtSurname.Text;
                employee.Postion = cbPosition.Text;
                employee.EmployeeID = num.Next(1000, 9999);
                string sql = "select * from [dbo].[Employee] where EmployeeID = @empid";
                cmd = new SqlCommand(sql, conn);
                //Checks for identical EmployeeID entries then re-randomizes AppointmentID
                cmd.CommandText = sql; 
                cmd.Parameters.AddWithValue("@empid", employee.EmployeeID);
                count = Convert.ToInt32(cmd.ExecuteScalar());
                if (count == 1)
                {
                    employee.EmployeeID = num.Next(1000, 9999);
                }

                sql = "INSERT INTO [dbo].[Employee] (EmployeeID,EmpName,EmpSurname,Postion) VALUES (@id,@name,@surname,@position);";
                cmd = new SqlCommand(sql, conn);
                // Lets insert something into our new table:
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@id", Convert.ToInt32(employee.EmployeeID));
                cmd.Parameters.AddWithValue("@name", employee.Name);
                cmd.Parameters.AddWithValue("@surname", employee.Surname);
                cmd.Parameters.AddWithValue("@position", employee.Postion);
                //Execute query to insert data into database
                cmd.ExecuteNonQuery();
                cmd.Parameters.Clear();
                MessageBox.Show("Employee successfully made");
                Clear();
            }
            catch (Exception e)
            {
                MessageBox.Show("Error add employee\n" + e);
                Clear();
            }
            finally {
                conn.Close();
            }
           
        }

        public void Clear()
        {
            txtName.Text = "";
            txtSurname.Text = "";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            WriteToDatabase();
        }

       

        private void addVehicleToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AddVehicle addVehicle = new AddVehicle();
            addVehicle.ShowDialog();
        }

        private void scheduleTripToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddTrip addTrip = new AddTrip();
            addTrip.ShowDialog();
        }

        private void viewReportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            a report = new a();
            report.ShowDialog();
        }

        private void makeAppointmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            MakeAppointment apoint = new MakeAppointment();
            apoint.ShowDialog();
        }

        private void deleteEmploeeRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Delete deleteEmp = new Delete();
            deleteEmp.ShowDialog();
        }

        private void deleteVehicleRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            DeleteVehicle deleteVehicle = new DeleteVehicle();
            deleteVehicle.ShowDialog();
        }

        private void deleteAppointmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            DeleteAppointment deleteAppoint = new DeleteAppointment();
            deleteAppoint.ShowDialog();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }
    }
}
