Create table [dbo].[Vehicle]
(
VehicleNumberID int PRIMARY KEY not null,
RegistrationNumber nvarchar(50) not null,
Manufacturer nvarchar(50) not null,
EngineSize nvarchar(50) not null,
CurrOdometerReading int not null,
NextOdometerReading int not null


);