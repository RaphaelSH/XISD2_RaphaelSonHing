﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE
{
    class Vehicle
    {
        public int VehicleID { get; set; }
        public String RegistrationNumber { get; set; }
        public String VehicleType { get; set; }
        public String Manufacturer { get; set; }
        public String EngineSize { get; set; }
        public int CurrOdometer { get; set; }
        public int NextOdometer { get; set; }
    }
}
