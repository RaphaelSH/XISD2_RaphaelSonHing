﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace POE
{
    public partial class AddTrip : Form
    {
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataReader datareader;
        Trip trip = new Trip();
        Random num = new Random();
        Connection connect = new Connection(); 
        public AddTrip()
        {
            InitializeComponent();
            connectionDB();
            
        }

        //create database
        public void connectionDB()
        {
            string strConn = connect.getConnecection();
            // create a new database connection:
            conn = new SqlConnection (strConn);
         
           
        }

        public void WriteToDatabase()
        {
            int count = 0;
            

            try
            {
                conn.Open();


                trip.TripDate = dtpDate.Value.ToLongDateString();
                trip.KMtoTravel = Convert.ToInt32(nudKMtoTravel.Value);
                trip.KMTravelled = Convert.ToInt32(nudKMTravelled.Value);
                trip.Destination = txtDestination.Text;
                trip.TripID = num.Next(1000, 9999);

                string sql = "select * from [dbo].[Trip] where TripID = @tripid";
                cmd = new SqlCommand(sql, conn);
                //Checks for identical TripID entries then re-randomizes AppointmentID
                cmd.CommandText = sql; 
                cmd.Parameters.AddWithValue("@tripid", trip.TripID);
                count = Convert.ToInt32(cmd.ExecuteScalar());
                if (count == 1)
                {
                    trip.TripID = num.Next(1000, 9999);
                }



                sql = "INSERT INTO [dbo].[Trip] (TripID,TripDate,KMtoTravel,KMTravelled,Destination) VALUES (@id,@date,@kmtotravel,@kmtravelled,@destination)";
                cmd = new SqlCommand(sql, conn);
                // Lets insert something into our new table:
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@id", Convert.ToInt32(trip.TripID));
                cmd.Parameters.AddWithValue("@date", trip.TripDate);
                cmd.Parameters.AddWithValue("@kmtotravel", Convert.ToInt32(trip.KMtoTravel));
                cmd.Parameters.AddWithValue("@kmtravelled", Convert.ToInt32(trip.KMTravelled));        
                cmd.Parameters.AddWithValue("@destination", trip.Destination);
                //Execute query to insert data into database
                cmd.ExecuteNonQuery();
                cmd.Parameters.Clear();
                MessageBox.Show("Trip successfully scheduled");
                Clear();
            }
            catch (Exception e)
            {
                MessageBox.Show("Error scheduling trip\n" + e);
                Clear();
            }
            finally {
                conn.Close();
            }
           
        }

        public void Clear()
        {
            txtDestination.Text  = "";
            nudKMtoTravel.Value = 0;
            nudKMTravelled.Value = 0;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            WriteToDatabase();
        }


       

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void addEmployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddEmployee employee = new AddEmployee();
            employee.ShowDialog();
        }

        private void addVehicleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddVehicle vehicle = new AddVehicle();
            vehicle.ShowDialog();
        }

        private void viewReportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            a reoprt = new a();
            reoprt.ShowDialog();
        }

        private void makeAppointmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            MakeAppointment appoint = new MakeAppointment();
            appoint.ShowDialog();
        }

        private void deleteEmploeeRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Delete deleteEmp = new Delete();
            deleteEmp.ShowDialog();
        }

        private void deleteVehicleRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            DeleteVehicle deleteVehicle = new DeleteVehicle();
            deleteVehicle.ShowDialog();
        }

        private void deleteAppointmentRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            DeleteAppointment deleteAppoint = new DeleteAppointment();
            deleteAppoint.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.ShowDialog();
        }
    }
}
