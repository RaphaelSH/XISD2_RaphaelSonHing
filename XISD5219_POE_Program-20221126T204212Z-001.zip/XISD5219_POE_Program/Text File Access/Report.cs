﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace POE
{
    public partial class a : Form
    {
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataReader datareader;
        Connection connect = new Connection();
        public a()
        {
            InitializeComponent();
            connectionDB();
            Prep();
        }

        public void Prep()
        {
            conn.Open();
            string sql = "select * from [dbo].[Appointment]";
            cmd = new SqlCommand(sql, conn);
            using (datareader = cmd.ExecuteReader())
            {
                while (datareader.Read())
                {
                    cbVehicleNo.Items.Add(datareader["VehicleNumberID"]);
                }
            }
            conn.Close();
        }

        public void connectionDB()
        {
            string strConn = connect.getConnecection();
            // create a new database connection:
            conn = new SqlConnection(strConn);
        }

        private void btnReport1_Click(object sender, EventArgs e)
        {
            Vehicle vehicle = new Vehicle();
            rtbDisplay.Clear();
            string output = "";
            int count = 1;
            try
            {
                conn.Open();
                string sql = "select * from [dbo].[Vehicle]";
                cmd = new SqlCommand(sql, conn);
                cmd.CommandText = sql;

              
                using (datareader = cmd.ExecuteReader())
                {
                    while (datareader.Read())
                    {
                        vehicle.VehicleID = (int)datareader["VehicleNumberID"];
                        vehicle.RegistrationNumber = (string)datareader["RegistrationNumber"];
                        vehicle.VehicleType = (string)datareader["VehicleType"];
                        vehicle.Manufacturer = (string)datareader["Manufacturer"];
                        vehicle.EngineSize = (string)datareader["EngineSize"];
                        vehicle.CurrOdometer = (int)datareader["CurrOdometerReading"];
                        vehicle.NextOdometer = (int)datareader["NextOdometerReading"];
                        
                                    output += "\nVehicle " +count
                                          +"\n**********************"                                           
                                          +"\nVehicleID: "+vehicle.VehicleID
                                          +"\nRegistration Number: "+vehicle.RegistrationNumber
                                          + "\nManufacturer: " + vehicle.Manufacturer
                                          + "\nEngine Size: "+vehicle.EngineSize
                                          + "\nOdometer Reading (Current): "+vehicle.CurrOdometer
                                          +"\nOdometer Reading (Next):"+vehicle.NextOdometer+"\n\n";
                    count++;
                    }
                      rtbDisplay.Text = "Vehicle Status Report"+
                         "\n------------------------------------"+output;
                    datareader.Close();
                }
            }
            catch (Exception t)
            {
                MessageBox.Show("Error Has occured during display\n"+t);
                rtbDisplay.Clear();
            }
            conn.Close();
        }

        private void btnReport2_Click(object sender, EventArgs e)
        {
            Appointment appoint = new Appointment();
            rtbDisplay.Clear();
            string output = "";
            int count = 1;
            try
            {
                conn.Open();
                string sql = "select * from [dbo].[Appointment]";
                cmd = new SqlCommand(sql, conn);
                cmd.CommandText = sql;


                using (datareader = cmd.ExecuteReader())
                {
                    while (datareader.Read())
                    {
                        appoint.AppointmentDate = (string)datareader["AppointmentDate"];
                        appoint.VehicleNumber = (int)datareader["VehicleNumberID"];
                        appoint.ServiceType = (string)datareader["services_to_be_performed"];
                        appoint.ProcedureCode = (string)datareader["ProcedureCode"];
                        appoint.Description = (string)datareader["Description"];
                        
                      

                        output += "\nAppointment " + count
                              + "\n**********************"
                              + "\nAppointment Date: " + appoint.AppointmentDate
                              + "\nVehicleNumberID: " + appoint.VehicleNumber
                              + "\nServices to be performed: " + appoint.ServiceType
                              + "\nProcedure Code: " + appoint.ProcedureCode
                              + "\nDescription: " + appoint.Description + "\n\n";
                              
                        count++;
                    }
                    rtbDisplay.Text = "Service Appointment List" +
                       "\n------------------------------------" + output;
                    datareader.Close();
                }
            }
            catch (Exception t)
            {
                MessageBox.Show("Error Has occured during display\n" + t);
                rtbDisplay.Clear();
            }
            conn.Close();
        }

        private void btnReport3_Click(object sender, EventArgs e)
        {
            Appointment appoint = new Appointment();
            rtbDisplay.Clear();
            string output = "";
            int count = 1;
            try
            {
                conn.Open();
                string sql = "select * from [dbo].[Appointment] where VehicleNumberID = @vehicleid order by AppointmentDate Asc";
                cmd = new SqlCommand(sql, conn);
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@vehicleid", cbVehicleNo.Text);


                using (datareader = cmd.ExecuteReader())
                {
                    while (datareader.Read())
                    {
                        appoint.AppointmentDate = (string)datareader["AppointmentDate"];
                        appoint.VehicleNumber = (int)datareader["VehicleNumberID"];
                        appoint.ServiceType = (string)datareader["services_to_be_performed"];
                        appoint.ProcedureCode = (string)datareader["ProcedureCode"];
                        appoint.Description = (string)datareader["Description"];
                        output += "\nAppointment " + count
                              + "\n**********************"
                              + "\nAppointment Date: " + appoint.AppointmentDate
                              + "\nVehicleNumberID: " + appoint.VehicleNumber
                              + "\nServices to be performed: " + appoint.ServiceType
                              + "\nProcedure Code: " + appoint.ProcedureCode
                              + "\nDescription: " + appoint.Description + "\n\n";

                        count++;
                    }
                    rtbDisplay.Text = "Service Appointment List" +
                       "\n------------------------------------" + output;
                    datareader.Close();
                    
                }
                cmd.Parameters.Clear();
            }
            catch (Exception t)
            {
                MessageBox.Show("Error Has occured during display\n" + t);
                rtbDisplay.Clear();
            }
            conn.Close();
        }

        private void addVehicleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddVehicle addVehicle = new AddVehicle();
            addVehicle.ShowDialog();
        }

       

        private void addEmployeeToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AddEmployee employee = new AddEmployee();
            employee.ShowDialog();
        }

        private void addVehicleToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AddVehicle vehicle = new AddVehicle();
            vehicle.ShowDialog();
        }

        private void scheduleTripToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddTrip trip = new AddTrip();
            trip.ShowDialog();
        }

        private void makeAppointmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            MakeAppointment appoint = new MakeAppointment();
            appoint.ShowDialog();
        }

        private void btnReport6_Click(object sender, EventArgs e)
        {

            {
               Trip  trip = new Trip();
                rtbDisplay.Clear();
                string output = "";
                int count = 1;
                try
                {
                    conn.Open();
                    string sql = "select * from [dbo].[Trip]";
                    cmd = new SqlCommand(sql, conn);
                    cmd.CommandText = sql;
                    


                    using (datareader = cmd.ExecuteReader())
                    {
                        while (datareader.Read())
                        {
                            trip.TripID = (int)datareader["TripID"];
                            trip.TripDate = (string)datareader["TripDate"];
                            trip.KMtoTravel = (int)datareader["KMtoTravel"];
                            //trip.KMTravelled = (int)datareader["KMTravelled"];
                            trip.Destination = (string)datareader["Destination"];
                            output += "\nTrip " + count
                                  + "\n**********************"
                                  + "\nTrip Date: " + trip.TripDate
                                  + "\nTrip ID: " + trip.TripID
                                  + "\n:KM to travel " + trip.KMtoTravel
                               
                                  + "\nDestination: " + trip.Destination + "\n\n";

                            count++;
                        }
                        rtbDisplay.Text = "Trip Report" +
                           "\n------------------------------------" + output;
                        datareader.Close();

                    }
                    cmd.Parameters.Clear();
                }
                catch (Exception t)
                {
                    MessageBox.Show("Error Has occured during display\n" + t);
                    rtbDisplay.Clear();
                }
                conn.Close();
            }
        }

        private void btnReport7_Click(object sender, EventArgs e)
        {

            {

                {
                    Trip trip = new Trip();
                    rtbDisplay.Clear();
                    string output = "";
                    int count = 1;
                    try
                    {
                        conn.Open();
                        string sql = "select * from [dbo].[Trip]";
                        cmd = new SqlCommand(sql, conn);
                        cmd.CommandText = sql;



                        using (datareader = cmd.ExecuteReader())
                        {
                            while (datareader.Read())
                            {
                                trip.TripID = (int)datareader["TripID"];
                                trip.TripDate = (string)datareader["TripDate"];
                                //trip.KMTravelled = (int)datareader["KMTravelled"];
                                trip.Destination = (string)datareader["Destination"];
                                output += "\nTrip " + count
                                      + "\n**********************"
                                      + "\nTrip Date: " + trip.TripDate
                                      + "\nTrip ID: " + trip.TripID
                                      + "\n:KM travelled " + trip.KMTravelled
                                      + "\nDestination: " + trip.Destination + "\n\n";

                                count++;
                            }
                            rtbDisplay.Text = "Trip Report" +
                               "\n------------------------------------" + output;
                            datareader.Close();

                        }
                        cmd.Parameters.Clear();
                    }
                    catch (Exception t)
                    {
                        MessageBox.Show("Error Has occured during display\n" + t);
                        rtbDisplay.Clear();
                    }
                    conn.Close();
                }
            }
        }

        private void btnReport8_Click(object sender, EventArgs e)
        {

            {

                {
                    TimeSheet timesheet = new TimeSheet();
                    rtbDisplay.Clear();
                    string output = "";
                    int count = 1;
                    try
                    {
                        conn.Open();
                        string sql = "select * from [dbo].[TimeSheet]";
                        cmd = new SqlCommand(sql, conn);
                        cmd.CommandText = sql;



                        using (datareader = cmd.ExecuteReader())
                        {
                            while (datareader.Read())
                            {
                                timesheet.EmployeeID = (int)datareader["EmployeeID"];
                                timesheet.WorkDate = (string)datareader["WorkDate"];
                                timesheet.HoursWorked = (int)datareader["HoursWorked"];
                                
                           
                                output += "\nEmployee " + count
                                      + "\n**********************"
                                      + "\nEmployee ID: " + timesheet.EmployeeID
                                      + "\nTrip ID: " + timesheet.WorkDate
                                      + "\n:KM to travel " + timesheet.HoursWorked + "\n\n";

                               

                                count++;
                            }
                            rtbDisplay.Text = "Timesheet Report" +
                               "\n------------------------------------" + output;
                            datareader.Close();

                        }
                        cmd.Parameters.Clear();
                    }
                    catch (Exception t)
                    {
                        MessageBox.Show("Error Has occured during display\n" + t);
                        rtbDisplay.Clear();
                    }
                    conn.Close();
                }
            }
        }

        private void deleteEmploeeRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Delete deleteEmp = new Delete();
            deleteEmp.ShowDialog();
        }

        private void deleteVehicleRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            DeleteVehicle deleteVehicle = new DeleteVehicle();
            deleteVehicle.ShowDialog();
        }

        private void deleteAppointmentRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            DeleteAppointment deleteAppoint = new DeleteAppointment();
            deleteAppoint.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.ShowDialog();
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
