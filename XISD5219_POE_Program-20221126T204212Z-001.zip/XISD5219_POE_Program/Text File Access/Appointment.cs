﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE
{
    class Appointment : Services
    {
        public int AppointmentID { get; set; }
        public string AppointmentTime { get; set; }
        public string AppointmentDate { get; set; }
        public int VehicleNumber { get; set; }
       

    }
}
