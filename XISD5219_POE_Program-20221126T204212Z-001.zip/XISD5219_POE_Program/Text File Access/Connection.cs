﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE
{
    class Connection
    {
        public string getConnecection()
        {
            //Used earier versions
            string strConn = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=F:\XISD\XISD5219_POE_Program (1)\XISD5219_POE_Program\Text File Access\Cargon_Fleet_1.mdf;Integrated Security=True;Connect Timeout=30";
            
            
            //Used for later versions
            //string strConn = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Exam work\XISD5219\C# Database Access\Text File Access\Cargo-Fleet.mdf;Integrated Security=True;Connect Timeout=30";
                
                /*@"Data Source = DESKTOP-47UI1O8;
            Integrated Security=True; Initial Catalog = AAA_College;";/
            /*string myConnection = @"Data Source = DESKTOP-47UI1O8;
            user id=sa; password=Password1; Initial Catalog = XYZ_College;";
            * */
            return strConn;
        }
    }
}
