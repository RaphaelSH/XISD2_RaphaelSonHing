﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace POE
{
    public partial class Login : Form
    {
        SqlCommand command;
        SqlConnection conn;
        public static List<int> useridList = new List<int>();
        Random num = new Random();
        public int useridRandom;
        Connection connect = new Connection();
        public Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            using (conn = new SqlConnection(connect.getConnecection()))
            {
                conn.Open();
                string qry1 = "SELECT COUNT(1) from [dbo].[User] WHERE UserName = @username and PassWord = @password";
                command = new SqlCommand(qry1, conn);
                command.Parameters.AddWithValue("@username", txtUsername.Text);
                command.Parameters.AddWithValue("@password", txtPassword.Text);
                int count = Convert.ToInt32(command.ExecuteScalar());

                if (count == 1)
                {
                    MessageBox.Show("Login Successful");

                }
                else
                {
                    MessageBox.Show("Login Unsuccessful");
                    Clear();
                }

                conn.Close();

            }

            using (conn = new SqlConnection(connect.getConnecection()))
            {
                conn.Open();
                string qry = "SELECT * from [dbo].[User] WHERE UserName = @username and PassWord = @password";
                command = new SqlCommand(qry, conn);
                command.Parameters.AddWithValue("@username", txtUsername.Text);
                command.Parameters.AddWithValue("@password", txtPassword.Text);


                using (SqlDataReader datareader = command.ExecuteReader())
                {

                    while (datareader.Read())
                    {
                        useridRandom = (int)datareader["UserId"];
                        useridList.Add(useridRandom);
                    }

                    datareader.Close();

                }


                conn.Close();
            }

            Clear();
            this.Hide();
            MakeAppointment apoint = new MakeAppointment();
            apoint.ShowDialog();
        }

        public void Clear()
        {
            txtUsername.Clear();
            txtPassword.Clear();
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {

            {
                using (SqlConnection conn = new SqlConnection(connect.getConnecection()))
                {
                    try
                    {
                        conn.Open();
                        string qrylogin = "INSERT INTO [dbo].[User] VALUES (@userid,@username,@password)";
                        command = new SqlCommand(qrylogin, conn);
                        command.Parameters.AddWithValue("@username", txtUsername.Text);
                        command.Parameters.AddWithValue("@password", txtPassword.Text);
                        useridRandom = num.Next(1, 15000);
                        command.Parameters.AddWithValue("@userid", Convert.ToInt32(useridRandom));
                        useridList.Add(useridRandom);
                        MessageBox.Show("User addition Successful");
                        Clear();
                        conn.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("User addition Unsuccessful\n" + ex);
                    }

                }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (cmbSelect.Text.Equals("AddEmployee"))
            {
                AddEmployee adEm = new AddEmployee();
                adEm.ShowDialog();
            }
            else if (cmbSelect.Text.Equals("AddTrip"))
            {
                AddTrip adTri = new AddTrip();
                adTri.ShowDialog();
            }
            else if (cmbSelect.Text.Equals("frmRe"))
            {
                AddVehicle adVeh = new AddVehicle();
                adVeh.ShowDialog(); ;
            }
            else if (cmbSelect.Text.Equals("Delete"))
            {
                Delete del = new Delete();
                del.ShowDialog(); ;
            }

            else if (cmbSelect.Text.Equals("DeleteAppointment"))
            {
                DeleteAppointment delApp = new DeleteAppointment();
                delApp.ShowDialog(); ;
            }

            else if (cmbSelect.Text.Equals("DeleteAppointment"))
            {
                DeleteVehicle delVeh = new DeleteVehicle();
                delVeh.ShowDialog(); ;
            }

            else if (cmbSelect.Text.Equals("Login"))
            {
                Login log = new Login();
                log.ShowDialog(); ;
            }
            else if (cmbSelect.Text.Equals("MakeAppointment"))
            {
                MakeAppointment makApp = new MakeAppointment();
                makApp.ShowDialog(); ;
            }

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
