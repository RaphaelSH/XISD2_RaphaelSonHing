﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace POE
{
    public partial class MakeAppointment : Form
    {
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataReader datareader;
        Appointment appointment = new Appointment();
        Random num = new Random();
        Connection connect = new Connection();
        public MakeAppointment()
        {
            InitializeComponent();
            connectionDB();
            Prep();
        }

        //create database
        public void connectionDB()
        {

            string strConn = connect.getConnecection();
           
            conn = new SqlConnection (strConn);
         
           
        }

        public void Prep()
        {
            cbServiceType.Items.Clear();
            cbVehicleID.Items.Clear();
            conn.Open();
            string sql = "select * from [dbo].[Services]";
            cmd = new SqlCommand(sql,conn);

            using (datareader = cmd.ExecuteReader())
            { 
                while(datareader.Read())
                {
                    cbServiceType.Items.Add(datareader["ServiceType"]);
                }
            }

            sql = "select * from [dbo].[Vehicle]";
            cmd = new SqlCommand(sql, conn);
            using (datareader = cmd.ExecuteReader())
            {
                while (datareader.Read())
                {
                  cbVehicleID.Items.Add(datareader["VehicleNumberID"]);
                }
            }
            conn.Close();
        }
        public void WriteToDatabase()
        {
            int count = 0;
            

            try
            {
                conn.Open();
                string service = cbServiceType.Text;
                cmd.CommandText = "select * from [dbo].[Services] where ServiceType = @services";
                cmd.Parameters.AddWithValue("@services", cbServiceType.Text);

                using (datareader = cmd.ExecuteReader())
                {
                    while (datareader.Read())
                    {
                        appointment.ProcedureCode = (string)datareader["ProcedureCode"];
                        appointment.ServiceType = (string)datareader["ServiceType"];
                        appointment.Description = (string)datareader["Description"];
                    }
                    datareader.Close();
                }


                appointment.VehicleNumber = Convert.ToInt32(cbVehicleID.Text);
                appointment.AppointmentDate = dtpAppointmentDate.Value.ToLongDateString();
                appointment.AppointmentID = num.Next(1000, 9999);

                //Checks for identical ApppointmentID entries then re-randomizes AppointmentID
                cmd.CommandText = "select * from [dbo].[Appointment] where AppointmentID = @appid";
                cmd.Parameters.AddWithValue("@appid", appointment.AppointmentID);
                count = Convert.ToInt32(cmd.ExecuteScalar());
                if (count == 1)
                {
                    appointment.AppointmentID = num.Next(1000, 9999);
                }


                // Lets insert something into our new table:
                cmd.CommandText = "INSERT INTO [dbo].[Appointment] (AppointmentID,AppointmentDate,VehicleNumberID,services_to_be_performed,ProcedureCode,Description) VALUES (@id,@date,@vehicleid,@service,@procedurecode,@description);";
                cmd.Parameters.AddWithValue("@id", Convert.ToInt32(appointment.AppointmentID));
                cmd.Parameters.AddWithValue("@date", Convert.ToDateTime(appointment.AppointmentDate));
                cmd.Parameters.AddWithValue("@vehicleid", Convert.ToInt32(appointment.VehicleNumber));
                cmd.Parameters.AddWithValue("@service", appointment.ServiceType);
                cmd.Parameters.AddWithValue("@procedurecode", appointment.ProcedureCode);
                cmd.Parameters.AddWithValue("@description", appointment.Description);
                //Execute query to insert data into database
                cmd.ExecuteNonQuery();
                cmd.Parameters.Clear();
                MessageBox.Show("Appointment successfully made");
                //clear the data entry controls
            }
            catch (Exception e)
            {
                MessageBox.Show("Error add appointment\n" + e);
            }
            finally {
                conn.Close();
            }
           
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
                //call method to add product to text file
            WriteToDatabase();
        }

       

        private void addEmployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddEmployee addEmployee = new AddEmployee();
            addEmployee.ShowDialog();
        }

        private void addVehicleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddVehicle addVehicle = new AddVehicle();
            addVehicle.ShowDialog();
        }

        private void scheduleTripToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddTrip addTrip = new AddTrip();
            addTrip.ShowDialog();
        }

        private void viewReportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            a viewReport = new a();
            viewReport.ShowDialog();
        }

        private void deleteEmploeeRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Delete deleteEmp = new Delete();
            deleteEmp.ShowDialog();
        }

        private void deleteVehicleRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            DeleteVehicle deleteVehicle = new DeleteVehicle();
            deleteVehicle.ShowDialog();
        }

        private void deleteAppointmentRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            DeleteAppointment deleteAppoint = new DeleteAppointment();
            deleteAppoint.ShowDialog();
        }
    }
}
